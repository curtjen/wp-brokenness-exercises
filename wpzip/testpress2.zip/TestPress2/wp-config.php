<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'kloutier_wo5444');

/** MySQL database username */
define('DB_USER', 'kloutier_wo5444');

/** MySQL database password */
define('DB_PASSWORD', 'OcyeQWmBFBIu');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '>XGoJ]+z|Vn+^-=b&[cb>=>}?IhL=vSFPmyCqvNHkX*x+M]Adxhs{v@U<ifC{y[kVdW=_%hGMHo]]pcRVfJAz/a%(fRG?^^IjwS&N{bXajq<cCNQmwfH/>*FD|]mMkYU');
define('SECURE_AUTH_KEY', 'nM>Ch![&iI!r{rjcuTEfyK=r=og-kNCs;o;h|)/KQNJAgvFxuA<;dSW%A_EqK]+*g?nQi{!C!wZ(g@QY]Sw)V^^T)]r@N]?lG|M{z@d!eXPG[oNjyDO!es[ckqj?$|Hb');
define('LOGGED_IN_KEY', 'mTaf@&G-$!/]=-fV^ZprSYcTjB>w%?CXl=iV?w$VtWDd>EQ*qMSYA-RTE<Vuc*[XPG[gWVjF!R-(OU{/p/;lMYWuBlTeyqCmoEbQg^K*li!JMzt&LJ&<GcP&IX$G+kW;');
define('NONCE_KEY', '^OFNZGbiIpWp!pk@vsDq%s&$BPRUlbatU&_tq^)>;mdm[fO[OWzTsBX[Jf_%^ygBtm&[qWwwVU|>=^!KlJ&q{caSe?D*b&&rgoqOS=ELZ;LXk-/j&d{Dlfo{C(t${BiI');
define('AUTH_SALT', 'f}&>zcVKj<(SNeboJbsDNHVWr?(vDbU-c<OH!xFk^s?])eVT}pV>@UxFF%ahJ%in)gIAHV*u}T(lWmMbsz?/<vaGagPmUArd%I)I<f(;*mPpwHCsA&b!x[We)h}Ir+OF');
define('SECURE_AUTH_SALT', '!;C[PaPmA)bxWwDCxn;--Q;N*bMXJTTQQx<GLSc?&jfybYvu^>$SrNm[l>X^>;M^L*_AXat[(@f-Hq;/_q@q[Tnveoh+nhY}G;D<{pOWR!qELf+dkiWzSqad|Go^MI?X');
define('LOGGED_IN_SALT', 'aNO;cV_kjQ)[$ZJVhcNnT_iNWTyT!<<U?;tbtE!Z^lQ)RBR]g{f|kFqExgI>$yq@nx[@$K?ykz>oBAJY-^ppN$)GZXM|vsGAPQGkT?*qrm/f$P%XBzeTD))WOzSFYZc;');
define('NONCE_SALT', 'Jiea]RBexsr};]]Z!aAMb)HEXzjJ-!AtASo^Hg{KkY*_?(HWB_FXR+{$qqrXBtdTqdNtG]{c@*!pDI(Wk%YQ[TLRComMn<-uAP|rn*mf^YoG%=&t)kG(_@KfT|={_yby');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_rdyq_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

/**
 * Include tweaks requested by hosting providers.  You can safely
 * remove either the file or comment out the lines below to get
 * to a vanilla state.
 */
if (file_exists(ABSPATH . 'hosting_provider_filters.php')) {
	include('hosting_provider_filters.php');
}
