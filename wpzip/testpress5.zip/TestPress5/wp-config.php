<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'kloutier_wo0793');

/** MySQL database username */
define('DB_USER', 'kloutier_wo0793');

/** MySQL database password */
define('DB_PASSWORD', '54X9SXITejxL');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', 'pjh&qwxCy}T|shcydL[gG){%(Fu_iZ|S/$kAOja=@cmlG/mxP^J-MTG@?/wyYIzym%?pzDrDH&)ICDQmTFTfYt(YagYcg$tsqYu_Pr(s>Ki>PPN|Pv[j;Gb{VHM?NlAu');
define('SECURE_AUTH_KEY', 'Wv<(>NyXF|Q<zlP+]c[/m;(+IpmTW;oZX!Bo+IfEuGxTUnWZ_Kl;nITqnxcpA{-pDb-IdjLQM;Nhzl_jDqd*^>;%g>G=*{r*Q%*[)Mm^Ybv|ZWQ=qm%eE<&^lAWQHX{{');
define('LOGGED_IN_KEY', 'e;>/tDkTWz=Zr^rh)^qXOQ+>pfnsnvE}O?z;$InKMiPbVRk@@>ixzFm}wLCSWMmEIWUT}KA{ZN?c[Ec<rOJZwg%u};BL<jKgEvEsvyhF{NYtej>uvip-YGUSaFvWBzjp');
define('NONCE_KEY', '>HFZ>ep]Bvl=F|_o+Jk{sySOAqiOFny}[OJbL%h?pED!_AAZ>Qk@hB;rRRyo&yWMxQ_eHL@@iBdo@Ak]>fxn;)^v--n%jDUN&iUCXUPW/<sXjjeqBV[Y/%]-[=FS]NF}');
define('AUTH_SALT', 'DD<EF(r{|d)>-I]&RRqNa;rr&Nv?a|FH&D<]S!jLfx&[OQ&(xPiuEzQ]S${mToViy<mkso/n&|b+cuGv_hi<-EaBXX_^/_w%mRr[bz-]K;J+%bmGThpVUanIDl&icuz^');
define('SECURE_AUTH_SALT', 'h^)j>}l&)Qv$=AQhM^h+-fDJUaCVhkYc_LoIgAJ^vOk({&b_OIA/GlrI{Py_|iY!BFjwBk]g>eM$Fyw!>-x}Z^%xSjrdk((Ons*zCJ_NH(YxpKoEW<Mx*<Bdro|mtYf*');
define('LOGGED_IN_SALT', 'GWhaZ{]Yc)BZV&YK]py*}_a)sYhEFQ/JqT]DTizF%Ma/zdrE+*-h-*[sg-sHUILvV<M-qvnCHZvIt}D@iKDE=epc*ya;ZD$EWegaFy;Ulo/a%WJ/)aZAM+O%UNK)@rQ}');
define('NONCE_SALT', 'PA]g=!GnIP^;V=l(kHrHFOAK)g;ZN_hj*R|l[lz?+{x/a&ZTgX-z=>=PI{CtG>y<oQmA&aoKvUN!XqpP-TIKg{DPSE$VuSaQmr>{oD@?x{|VOfDFELmRw*>oA}C&jdbh');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_rqsg_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

/**
 * Include tweaks requested by hosting providers.  You can safely
 * remove either the file or comment out the lines below to get
 * to a vanilla state.
 */
if (file_exists(ABSPATH . 'hosting_provider_filters.php')) {
	include('hosting_provider_filters.php');
}
