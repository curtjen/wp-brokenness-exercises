<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'kloutier_wo5401');

/** MySQL database username */
define('DB_USER', 'kloutier_wo5401');

/** MySQL database password */
define('DB_PASSWORD', 't4urvAmMM79T');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', 'OG[mP-rDb%Kt=DM^]!?Yq$[lshR$Pw!;=t>XpC{oUIGd^CIsna;$wxw^;dUFVh)DcyUjB|/jhr&}eb*hVS?pRv%ltmJJcobU;uXm$C<e}imr]bXDlPMfYGy+=</b>L((');
define('SECURE_AUTH_KEY', ';lFB[NnbW*k!PsWQcTWt)^BAo=bT=kg}d^D(G>+wHMc$x@K|$}O>KF=]g<V]AuP!f*jo/b+[]O_Dk|Pqb-(O|)nyQVRW$uKUySAl$%Oq!_+o/G}m<u}mVJiI?@!fw(d!');
define('LOGGED_IN_KEY', 'ba%$ppT)%C<YS(bD+AzftkE/cvosC=)l;duVVDEF;HC%@yG*KEj!?Dzf^F]vF@{U}AsvGgG/wqks!&!;H*@*eiUFgbSJFz}[Ao?dL<rDb&+AsjC_[S&J$-ynTDUzdY*C');
define('NONCE_KEY', 'x;Q{W?BYeHGI!$y{(+cujQqjfQ{wrO[A>RYAuY]((-Xm{Ga=qJvyPnpDn*WOu&]j[aORwzMWml+hv/^}P>!)&u]DN)X[I(TLEA}CeGRvj^gmc<D<;Z?;@N*uv^egf{ke');
define('AUTH_SALT', 'S;rL%_JUTy@lKf?RhKgSgSRiNtSonX^@(drH{Ld|OaDrc%s<]KE+*ml<!zWOnH%<qRd-f_{i/?-r[qcdy(&R-I!QYk{td-d@qF+z{KJfV;QvT@;LouiCe&<apaps?ebL');
define('SECURE_AUTH_SALT', 'F{[&QNSBKf+QVVN}efQx{NEfv}yQP)&-}NN$LY-IKxy(h%JmO@T$cXgxy->U}L}CvaT@(ZkPYsqA*z-[EAcdURdx}s)Vs_%eGMCNhLeQCvOwfEBu)Iv[k(chvjJx<^&^');
define('LOGGED_IN_SALT', '+{XIvx)<}tsEx^@E)Mj{<C_QepDHdPboCI?&I[mrMI(*OL^xj^r=BMw]y*tisARp?mM}OWZRLh=ktq[^@Rxn)We]]NxlMm&cUh}UoRXfGF[z+wIzbxXQRk=aP%<eT&^u');
define('NONCE_SALT', 'FQa$f*GZ_-BEG[pfq$uiG=w@z-KN<?@Sk@sSR;!qz|L{>NAK+YlrS+i>fwMpBB+JKiEj^KDn{=h!IDz<D%pxi>^?J!sx&m>y[$Qkp|kh?zqXfN)pq+KzTv|_{xz/PTFx');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_gglx_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

/**
 * Include tweaks requested by hosting providers.  You can safely
 * remove either the file or comment out the lines below to get
 * to a vanilla state.
 */
if (file_exists(ABSPATH . 'hosting_provider_filters.php')) {
	include('hosting_provider_filters.php');
}
