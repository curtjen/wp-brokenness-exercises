<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'kloutier_wo7661');

/** MySQL database username */
define('DB_USER', 'kloutier_wo7661');

/** MySQL database password */
define('DB_PASSWORD', 'IPzQdMJe9nZZ');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '{;a![&oJF^gJbKTwjQ-nHb])Vqre]C)QeLO[pK|rOf(Rsw{J;J$oP_L)kKlGb!mC*i%UG*t*^I[&tCLHtGhoWaiDD(XbT&)dhAsnRXAB@dvr/Q-nddKR;nBB@<iu<sSm');
define('SECURE_AUTH_KEY', 'ut$VLlTB<BfmymFVBvA&*O^pJ+%kwSeRMXi]TW!jWQRna+BgX<)V-z^AL-yn/(Z]F{Bp/|iG${ffEtN%d]&F$_C_d^Fs^uSbc(]A^qsy!cT(V!KkuO*%ZMq$oVR/$XfJ');
define('LOGGED_IN_KEY', 'LM/l<LeX%%(}Xy_dbvaTZOVR<Np^%c}|(Y]ki?_dmw_LKWJcn)MyxCq/X>kCR[^rjbDpHhuz_iTy[O}GDgNU<M_<>YJ%{%V*=>Rui_]f*rTJ|];mWU>SalP@OXpayFzm');
define('NONCE_KEY', 'jnQOo]FA<Il!;>lFtVt%UXX=Jl!/Twj{N}&BlKd/)lrdcF_%Otgw-+%%@]SAX{yn]L$GSo(VU%fnK!YVIGCzmbDf[!EtZZBXD}&hAY+Fn_$ye<v!B|knOr!_Ksy-F-Zp');
define('AUTH_SALT', '}%SaQfS$S&KkFy$UYXgYE{F($hJKrKhc[x^[d/?Cr/Namo|nfbEMoK-k>=BZuvnP/&Pt_v@v(iuWF}kALoUh[C!rAk^svXvq;D|+m|o[<Ok[e}RdOJkjX/SchTUKt{mA');
define('SECURE_AUTH_SALT', '[_pv@vhO+a@SNbjl}x([?^o?cDqouPmOk*byuohBt<ExsTEpXDJimUbA!XE!KOeyV?hQodOFlp$sEJ_}(^Ne|pm%ZTL+MIeWR<JE)^=QT@)%k$YR/^AfJY{xVk;yH)oG');
define('LOGGED_IN_SALT', 'kOHU|idjhhR+W^r?}P%rCu$z@]cwq|kt&cS)*uhThJpGlNc<}@MzqIg]b+D{i$R%>U_bq[a|pSyqbI!YhI|JyphblVa-Rnx(tc*royC?vF(kh{KJMh!(Sn(ssruXCi&L');
define('NONCE_SALT', 'YNQJKQ=a!D->[xun-vPy|/Et^*Yf?o>@rW-tnclr>KqjlnjMrd)<LW%RqT=X}Qae;*hqiCOgRO*tZ$ddTG]tA*ncyOR@ZKGtKTK?JF=oDoWMAN-I*D{@a;rN(Yu+M(_(');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_kjyh_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

/**
 * Include tweaks requested by hosting providers.  You can safely
 * remove either the file or comment out the lines below to get
 * to a vanilla state.
 */
if (file_exists(ABSPATH . 'hosting_provider_filters.php')) {
	include('hosting_provider_filters.php');
}
